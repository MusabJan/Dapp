import { ethers } from "ethers";

const contractAddress = "PASTE_CONTRACT_ADDRESS";

const abi = [
  "function createProduct(string _name, string _origin)",
  "function getProduct(uint _id) view returns (tuple(uint,string,string,address,uint))",
  "function productCount() view returns (uint)"
];

export async function getContract() {
    if (!window.ethereum) {
        alert("Install MetaMask");
        return;
    }

    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();

    return new ethers.Contract(contractAddress, abi, signer);
}
