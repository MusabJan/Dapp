import { useState } from "react";
import { getContract } from "./blockchain";

function App() {

  const [name, setName] = useState("");
  const [origin, setOrigin] = useState("");
  const [product, setProduct] = useState(null);

  async function addProduct() {
    const contract = await getContract();
    const tx = await contract.createProduct(name, origin);
    await tx.wait();
    alert("Product Added on Blockchain!");
  }

  async function fetchProduct() {
    const contract = await getContract();
    const data = await contract.getProduct(1);
    setProduct(data);
  }

  return (
    <div style={{ padding: "20px" }}>
      <h1>AgriChain Pro DApp</h1>

      <input placeholder="Product Name" onChange={(e)=>setName(e.target.value)} />
      <input placeholder="Origin" onChange={(e)=>setOrigin(e.target.value)} />

      <button onClick={addProduct}>Add Product</button>
      <button onClick={fetchProduct}>Get Product #1</button>

      {product && (
        <div>
          <p>Name: {product[1]}</p>
          <p>Origin: {product[2]}</p>
          <p>Owner: {product[3]}</p>
        </div>
      )}
    </div>
  );
}

export default App;
