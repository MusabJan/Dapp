const hre = require("hardhat");

async function main() {
    const AgriChain = await hre.ethers.getContractFactory("AgriChain");
    const agri = await AgriChain.deploy();

    await agri.waitForDeployment();

    console.log("Contract deployed to:", await agri.getAddress());
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});
