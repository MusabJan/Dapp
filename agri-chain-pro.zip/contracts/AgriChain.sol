// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract AgriChain {

    struct Product {
        uint id;
        string name;
        string origin;
        address currentOwner;
        uint timestamp;
    }

    uint public productCount;
    mapping(uint => Product) public products;

    event ProductCreated(uint id, string name, string origin, address owner, uint time);

    function createProduct(string memory _name, string memory _origin) public {
        productCount++;

        products[productCount] = Product(
            productCount,
            _name,
            _origin,
            msg.sender,
            block.timestamp
        );

        emit ProductCreated(productCount, _name, _origin, msg.sender, block.timestamp);
    }

    function getProduct(uint _id) public view returns (Product memory) {
        return products[_id];
    }
}
