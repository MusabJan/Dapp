# AgriChain DApp

Simple demo project for university assignment.

## Features
- MetaMask wallet connect
- Simple UI

## How to run
Just open index.html in browser
