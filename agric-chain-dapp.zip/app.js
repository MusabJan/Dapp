async function connectWallet() {
  if (window.ethereum) {
    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    document.getElementById('status').innerText = 'Connected: ' + accounts[0];
  } else {
    alert('MetaMask install karo!');
  }
}
